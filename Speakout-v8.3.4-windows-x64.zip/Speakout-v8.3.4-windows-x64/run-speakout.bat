@echo off
title Speakout v8.3.4
echo Starting Speakout Desktop Runtime v8.3.4...
start dist\index.html
