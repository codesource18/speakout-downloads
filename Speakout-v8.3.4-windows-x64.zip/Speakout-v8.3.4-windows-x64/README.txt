Speakout v8.3.4 (Windows x64 Edition)
=====================================
Open-source local-first voice dictation and prompt intelligence platform.

Features:
- Fast on-device neural dictation & multi-sentence prompt intelligence
- Direct clipboard insertion via native Windows SendInput API
- Clean numbered history blocks (#1, #2...) & Black/White monochrome mode
- Zero telemetry, 100% private and offline-capable
