Speakout v8.3.3 (Windows x64 Edition)
=====================================
Open-source local-first voice dictation and prompt intelligence platform.

Features:
- Fast on-device neural dictation & prompt intelligence
- Direct clipboard insertion via native Windows SendInput API
- Clean numbered history cards & Black/White monochrome mode
- Zero telemetry, 100% private and offline-capable

To run:
1. Double-click run-speakout.bat or open dist/index.html in WebView2/Edge.
2. Ensure microphone permissions are enabled in Windows Settings > Privacy > Microphone.
