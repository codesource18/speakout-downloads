@echo off
title Speakout v8.3.3
echo Starting Speakout Desktop Runtime v8.3.3...
start dist\index.html
